# Sistema de Gestão Oncológica - São José da Tapera/AL

## Programa Municipal de Apoio ao Paciente Oncológico

Sistema completo para gestão de pacientes oncológicos desenvolvido para a Prefeitura de São José da Tapera, Alagoas.

## Funcionalidades

### Dashboard
- Visão geral com estatísticas em tempo real
- Filtros por período (hoje, semana, mês, ano, todos os períodos)
- Gráficos interativos de distribuição por tipo de câncer e faixa etária
- Alertas para casos críticos

### Gestão de Pacientes
- Cadastro completo de pacientes com dados clínicos
- Lista interativa com busca e filtros
- Visualização detalhada de cada paciente
- Edição e atualização de informações

### Relatórios
- Geração de relatórios em PDF com logos institucionais
- Exportação para Excel com dados completos
- Sistema de alertas para casos críticos
- Resumo estatístico dos dados

## Tecnologias Utilizadas

### Frontend
- React 18 com Vite
- Tailwind CSS para estilização
- Shadcn/UI para componentes
- Lucide React para ícones
- Recharts para gráficos

### Backend
- Flask (Python)
- Flask-CORS para integração frontend/backend
- OpenPyXL para geração de arquivos Excel

## Instalação

### Pré-requisitos
- Node.js 18+ 
- Python 3.11+
- npm ou yarn

### Frontend

```bash
cd sistema-oncologico-final
npm install
npm run dev
```

O frontend estará disponível em `http://localhost:5173`

### Backend

```bash
cd oncology_api_flask
pip install -r requirements.txt
python app.py
```

O backend estará disponível em `http://localhost:5001`

## Estrutura do Projeto

```
sistema-oncologico-final/
├── src/
│   ├── App.jsx              # Componente principal
│   ├── ReportsComponent.jsx # Componente de relatórios
│   └── App.css             # Estilos globais
├── public/
│   ├── logo-prefeitura.png  # Logo da prefeitura
│   └── logo-programa.png    # Logo do programa
└── package.json

oncology_api_flask/
├── app.py                   # API Flask
└── requirements.txt         # Dependências Python
```

## Configuração

### Cores do Sistema
- Azul: #007BFF (Primária)
- Verde Água: #20C997 (Secundária)
- Branco: #FFFFFF (Fundo)

### Dados de Demonstração
O sistema inclui 6 pacientes de demonstração com dados completos para teste das funcionalidades.

### Credenciais de Acesso
- Usuário: admin
- Senha: 123456

## Funcionalidades Implementadas

✅ Dashboard com estatísticas em tempo real
✅ Filtro de período funcional
✅ Cadastro e listagem de pacientes
✅ Geração de relatórios PDF com logos
✅ Exportação para Excel
✅ Sistema de alertas
✅ Interface responsiva
✅ Navegação por abas laterais
✅ Gráficos interativos

## Deploy

Para deploy em produção:

1. Build do frontend:
```bash
cd sistema-oncologico-final
npm run build
```

2. Configurar servidor web (nginx/apache) para servir os arquivos estáticos
3. Configurar servidor Python para a API Flask
4. Ajustar URLs de produção no frontend

## Suporte

Sistema desenvolvido para a Prefeitura de São José da Tapera/AL
Coordenador: Nathanyell Melo

---

**Versão:** 1.0.0
**Data:** Setembro 2025
