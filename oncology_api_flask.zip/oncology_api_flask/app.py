from flask import Flask, request, jsonify, send_file
from io import BytesIO
from openpyxl import Workbook
from flask_cors import CORS
import os

app = Flask(__name__)
CORS(app)  # Permitir CORS para todas as rotas

@app.route("/")
def home():
    return jsonify({"message": "API do Sistema de Gestão Oncológica rodando com sucesso 🚀"})

@app.route("/login", methods=["POST"])
def login():
    data = request.get_json()
    username = data.get("username")
    password = data.get("password")
    
    # Credenciais de demonstração
    if username == "admin" and password == "123456":
        return jsonify({
            "success": True, 
            "token": "demo-token", 
            "user": {"username": "admin", "name": "Administrador"}
        })
    else:
        return jsonify({"success": False, "message": "Credenciais inválidas"}), 401

@app.route("/dashboard/stats")
def get_dashboard_stats():
    return jsonify({
        "total_patients": 6,
        "scheduled_appointments": 0,
        "average_age": 46,
        "gender_distribution": {"male": 3, "female": 3}
    })

@app.route("/patients")
def get_patients():
    return jsonify([
        {"id": 1, "name": "João Silva", "zone": "Urbana", "age": 45, "gender": "Masculino", "cancer_type": "Próstata"},
        {"id": 2, "name": "Maria Santos", "zone": "Rural", "age": 33, "gender": "Feminino", "cancer_type": "Mama"},
        {"id": 3, "name": "Pedro Oliveira", "zone": "Urbana", "age": 67, "gender": "Masculino", "cancer_type": "Pulmão"},
        {"id": 4, "name": "Ana Costa", "zone": "Rural", "age": 52, "gender": "Feminino", "cancer_type": "Tireoide"},
        {"id": 5, "name": "Carlos Ferreira", "zone": "Urbana", "age": 41, "gender": "Masculino", "cancer_type": "Cólon"},
        {"id": 6, "name": "Lucia Almeida", "zone": "Rural", "age": 38, "gender": "Feminino", "cancer_type": "Ovário"}
    ])

@app.route("/appointments", methods=["GET"])
def get_appointments():
    return jsonify([])

@app.route("/appointments", methods=["POST"])
def create_appointment():
    data = request.get_json()
    # Simular criação de agendamento
    return jsonify({
        "id": "123e4567-e89b-12d3-a456-426614174000",
        "patient_name": data.get("patient_name"),
        "doctor_name": data.get("doctor_name"),
        "appointment_date": data.get("appointment_date"),
        "appointment_time": data.get("appointment_time"),
        "notes": data.get("notes", "")
    })

@app.route("/export/excel")
def export_patients_to_excel():
    # Dados de demonstração (substituir por dados reais do banco de dados)
    patients_data = [
        {"id": "P001", "name": "Maria Silva Santos", "age": 58, "gender": "Feminino", "cancerType": "Mama", "stage": "Estágio II", "status": "Em Tratamento", "registrationDate": "2024-01-15", "lastConsultation": "2024-09-20", "hospital": "Hospital Regional", "zone": "Urbana", "city": "São José da Tapera", "neighborhood": "Centro", "phone": "(82) 99999-0001", "cpf": "123.456.789-01", "treatmentStartDate": "2024-02-01", "sessions": 12, "completedSessions": 8, "observations": "Paciente respondendo bem ao tratamento. Próxima consulta agendada.", "photo": None},
        {"id": "P002", "name": "João Santos Lima", "age": 65, "gender": "Masculino", "cancerType": "Próstata", "stage": "Estágio I", "status": "Curado", "registrationDate": "2023-11-10", "lastConsultation": "2024-09-19", "hospital": "Hospital Municipal", "zone": "Rural", "city": "São José da Tapera", "neighborhood": "Zona Rural", "phone": "(82) 99999-0002", "cpf": "234.567.890-12", "treatmentStartDate": "2023-12-01", "treatmentEndDate": "2024-06-15", "sessions": 20, "completedSessions": 20, "observations": "Tratamento concluído com sucesso. Paciente em remissão completa.", "photo": None},
        {"id": "P003", "name": "Ana Costa Oliveira", "age": 42, "gender": "Feminino", "cancerType": "Pulmão", "stage": "Estágio III", "status": "Em Tratamento", "registrationDate": "2024-03-20", "lastConsultation": "2024-09-18", "hospital": "Hospital Regional", "zone": "Urbana", "city": "São José da Tapera", "neighborhood": "Bairro Novo", "phone": "(82) 99999-0003", "cpf": "345.678.901-23", "treatmentStartDate": "2024-04-05", "sessions": 16, "completedSessions": 10, "observations": "Paciente em tratamento intensivo. Monitoramento constante necessário.", "photo": None},
        {"id": "P004", "name": "Pedro Lima Ferreira", "age": 71, "gender": "Masculino", "cancerType": "Cólon", "stage": "Estágio IV", "status": "Crítico", "registrationDate": "2024-02-28", "lastConsultation": "2024-09-17", "hospital": "Hospital Regional", "zone": "Urbana", "city": "São José da Tapera", "neighborhood": "Centro", "phone": "(82) 99999-0004", "cpf": "456.789.012-34", "treatmentStartDate": "2024-03-15", "sessions": 24, "completedSessions": 18, "observations": "Estado crítico. Cuidados paliativos. Família acompanhando.", "photo": None},
        {"id": "P005", "name": "Carmen Rodrigues", "age": 55, "gender": "Feminino", "cancerType": "Ovário", "stage": "Estágio II", "status": "Em Tratamento", "registrationDate": "2024-01-08", "lastConsultation": "2024-09-16", "hospital": "Hospital Municipal", "zone": "Rural", "city": "São José da Tapera", "neighborhood": "Sítio Esperança", "phone": "(82) 99999-0005", "cpf": "567.890.123-45", "treatmentStartDate": "2024-01-25", "sessions": 14, "completedSessions": 9, "observations": "Evolução positiva. Paciente colaborativa e otimista.", "photo": None},
        {"id": "P006", "name": "Roberto Silva", "age": 48, "gender": "Masculino", "cancerType": "Estômago", "stage": "Estágio I", "status": "Curado", "registrationDate": "2023-08-12", "lastConsultation": "2024-09-15", "hospital": "Hospital Regional", "zone": "Urbana", "city": "São José da Tapera", "neighborhood": "Vila Nova", "phone": "(82) 99999-0006", "cpf": "678.901.234-56", "treatmentStartDate": "2023-09-01", "treatmentEndDate": "2024-03-20", "sessions": 18, "completedSessions": 18, "observations": "Recuperação completa. Exames de controle normais.", "photo": None}
    ]

    wb = Workbook()
    ws = wb.active
    ws.title = "Pacientes Oncológicos"

    # Cabeçalhos
    headers = list(patients_data[0].keys()) if patients_data else []
    ws.append(headers)

    # Dados
    for patient in patients_data:
        ws.append([patient[key] for key in headers])

    # Salvar em um buffer de memória
    excel_file = BytesIO()
    wb.save(excel_file)
    excel_file.seek(0)

    return send_file(
        excel_file,
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        as_attachment=True,
        download_name="relatorio_pacientes.xlsx"
    )

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5001))
    app.run(host="0.0.0.0", port=port, debug=False)



